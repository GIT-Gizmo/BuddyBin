import React from "react";

interface Contact {
    id: number
    firstName: string
    lastName: string
    email: string
}

interface ContactListProps {
    contacts: Contact[];
    updateContact: () => void;
    updateCallback: () => void;
}

const ContactList: React.FC<ContactListProps> = ({ contacts, updateContact, updateCallback }) => {
    return (
        <main>
            <h2>Contacts</h2>

            <table>
                <thead>
                    <tr className="table-head">
                        <th>Frist Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {contacts.map((contact) => (
                        <tr key={contact.id}>
                            <td>{contact.firstName}</td>
                            <td>{contact.lastName}</td>
                            <td>{contact.email}</td>
                            <td>
                                <button onClick={() => updateContact(contact)}>Update</button>
                                <button>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </main>
    )
}

export default ContactList;